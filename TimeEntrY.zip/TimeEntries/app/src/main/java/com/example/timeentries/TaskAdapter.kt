package com.example.timeentries


import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(private val tasks: ArrayList<Task>){

    class TaskHolder(view: View) : RecyclerView.ViewHolder(view){
        val label: TextView = view.findViewById(R.id.label)
        val tot_hour: TextView = view.findViewById(R.id.tot_hour)
    }

}