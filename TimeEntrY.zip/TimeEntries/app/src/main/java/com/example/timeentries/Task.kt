package com.example.timeentries

data class Task(val label:String,val tot_hour:Double) {
}